//Enum para usuario admin e usuario padrao

package model;

public enum TipoUsuario {
    ADMIN, COMUM
}
